# Your Energy - Fitness Exercise Application

[![Vite](https://img.shields.io/badge/Vite-5.4.6-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-F7DF1E?logo=javascript&logoColor=black)](https://www.ecma-international.org/)
[![SCSS](https://img.shields.io/badge/SCSS-1.96.0-CC6699?logo=sass&logoColor=white)](https://sass-lang.com/)

**Your Energy** - це сучасний веб-додаток для перегляду та підбору фізичних вправ. Застосунок дозволяє користувачам переглядати каталог вправ за різними категоріями, додавати їх в обране та залишати відгуки.

## 🎯 Основні можливості

- 🏋️ **Каталог вправ** - перегляд вправ за категоріями (м'язи, частини тіла, обладнання)
- 🔍 **Пошук вправ** - швидкий пошук за ключовими словами
- ⭐ **Обране** - збереження улюблених вправ для швидкого доступу
- 💬 **Система рейтингу** - можливість залишати відгуки та оцінки
- 📱 **Адаптивний дизайн** - підтримка всіх типів пристроїв
- 🌓 **Темна/світла тема** - перемикання між темами оформлення
- 📄 **Пагінація** - зручна навігація по великому каталогу
- 💡 **Цитата дня** - мотиваційні цитати для натхнення

## 🚀 Технології

### Frontend Stack
- **Vite** - швидкий bundler та dev server
- **Vanilla JavaScript (ES6+)** - чистий JavaScript без фреймворків
- **SCSS** - препроцесор для стилів
- **Modern Normalize** - сучасний CSS reset

### Плагіни та інструменти
- `vite-plugin-html-inject` - інжекція HTML партіалів
- `vite-plugin-full-reload` - автоматичне оновлення при зміні HTML
- `postcss-sort-media-queries` - оптимізація media queries

### Оптимізації
- ✅ **Event Delegation** - оптимізована обробка подій на картках
- ✅ **Lazy Loading** - відкладене завантаження контенту
- ✅ **Code Splitting** - розділення коду для швидшого завантаження
- ✅ **Source Maps** - для зручного debugging

## 📦 Встановлення

### Передумови
Переконайтеся, що у вас встановлено:
- Node.js (версія 14 або вище)
- npm або yarn

### Кроки встановлення

1. **Клонуйте репозиторій**
```bash
git clone https://github.com/your-username/js-curse-project.git
cd js-curse-project
```

2. **Встановіть залежності**
```bash
npm install
```

3. **Запустіть dev сервер**
```bash
npm run dev
```

Застосунок буде доступний за адресою: `http://localhost:5173`

## 📜 Доступні команди

| Команда | Опис |
|---------|------|
| `npm run dev` | Запуск dev сервера з hot reload |
| `npm run build` | Створення production build |
| `npm run preview` | Перегляд production build локально |

## 🏗️ Структура проєкту

```
js-curse-project/
├── src/
│   ├── css/                    # SCSS стилі
│   │   ├── common.scss         # Загальні стилі
│   │   ├── variables.scss      # Змінні (кольори, розміри)
│   │   ├── header.scss         # Стилі хедера
│   │   ├── footer.scss         # Стилі футера
│   │   ├── home.scss           # Стилі головної сторінки
│   │   ├── exercises.scss      # Стилі каталогу вправ
│   │   ├── exercise-modal.scss # Стилі модалки вправи
│   │   ├── rating-modal.scss   # Стилі модалки рейтингу
│   │   └── fonts.scss          # Шрифти
│   │
│   ├── js/                     # JavaScript модулі
│   │   ├── exercises.js        # Каталог вправ та фільтри
│   │   ├── exercise-modal.js   # Модальне вікно вправи
│   │   ├── rating-modal.js     # Модальне вікно рейтингу
│   │   ├── favorites.js        # Робота з обраним
│   │   ├── header.js           # Функціонал хедера
│   │   └── quote.js            # Цитата дня
│   │
│   ├── partials/               # HTML компоненти
│   │   ├── header.html         # Хедер
│   │   ├── footer.html         # Футер
│   │   ├── home.html           # Головна секція
│   │   ├── exercises.html      # Каталог вправ
│   │   ├── exercise-modal.html # Модалка вправи
│   │   └── rating-modal.html   # Модалка рейтингу
│   │
│   ├── img/                    # Зображення
│   │   └── svg/                # SVG іконки
│   │
│   ├── fonts/                  # Шрифти
│   │   ├── DMSans.ttf
│   │   └── DMSans-Italic.ttf
│   │
│   ├── index.html              # Головний HTML файл
│   └── main.js                 # Точка входу JavaScript
│
├── dist/                       # Production build (генерується)
├── vite.config.js              # Конфігурація Vite
├── package.json                # Залежності та скрипти
└── README.md                   # Документація

```

## 🔌 API Integration

Застосунок використовує API від GoIT:

**Base URL:** `https://your-energy.b.goit.study/api`

### Endpoints

| Method | Endpoint | Опис |
|--------|----------|------|
| `GET` | `/filters` | Отримання фільтрів (категорій) |
| `GET` | `/exercises` | Отримання списку вправ |
| `GET` | `/exercises/:id` | Отримання деталей вправи |
| `POST` | `/exercises/:id/rating` | Додавання рейтингу |
| `GET` | `/quote` | Отримання цитати дня |
| `POST` | `/subscription` | Підписка на розсилку |

### Приклад запиту

```javascript
// Отримання вправ за фільтром
const response = await fetch(
  'https://your-energy.b.goit.study/api/exercises?muscles=biceps&page=1&limit=10'
);
const data = await response.json();
```

## 🎨 Особливості реалізації

### Event Delegation (Оптимізація)

Замість накладання окремих слухачів на кожну картку вправи, використовується делегування подій:

```javascript
// Один слухач на контейнер замість N слухачів на кожній картці
cardsContainer.addEventListener('click', event => {
  const card = event.target.closest('.exercises__content__main__cards-item');
  
  if (!card) return;
  
  // Зчитування даних з data-атрибутів
  const categoryName = card.getAttribute('data-category-name');
  const exerciseId = card.getAttribute('data-exercise-id');
  
  // Виконання відповідних дій
});
```

**Переваги:**
- ⚡ Один слухач замість N (де N може бути 100+)
- 💾 Менше споживання пам'яті
- 🚀 Швидший рендеринг карток
- 🔄 Автоматична робота з динамічним контентом

### LocalStorage для Обраного

```javascript
// Збереження обраних вправ
const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
favorites.push(exerciseId);
localStorage.setItem('favorites', JSON.stringify(favorites));
```

### Адаптивний дизайн

- Mobile First підхід
- Breakpoints: 375px, 768px, 1440px
- Flexible Grid система

## 🌟 Функціональність

### 1. Каталог Вправ
- Фільтрація за категоріями (М'язи, Частини тіла, Обладнання)
- Пагінація результатів
- Клік на категорію для перегляду вправ

### 2. Пошук
- Пошук за ключовими словами
- Debounce (1 секунда) для оптимізації запитів
- Фільтрація в межах обраної категорії

### 3. Модальне Вікно Вправи
- Детальна інформація про вправу
- GIF анімація виконання
- Інформація про калорії, час, цільові м'язи
- Кнопка додавання в обране
- Кнопка для залишення рейтингу

### 4. Система Рейтингу
- Оцінка від 1 до 5 зірок
- Текстовий відгук (до 200 символів)
- Валідація email

### 5. Обране
- Перегляд збережених вправ
- Синхронізація з LocalStorage
- Можливість видалення з обраного

### 6. Хедер
- Навігація між Home та Favorites
- Перемикач теми (світла/темна)
- Адаптивне меню для мобільних

## 🔧 Налаштування

### Зміна Base Path

У файлі `vite.config.js` змініть параметр `base`:

```javascript
base: command === 'serve' ? '/' : '/your-repo-name/',
```

### Додавання нових API endpoints

У файлі `src/js/exercises.js` або інших JS модулях:

```javascript
const API_BASE = 'https://your-energy.b.goit.study/api';

async function fetchData(endpoint) {
  const response = await fetch(`${API_BASE}${endpoint}`);
  return await response.json();
}
```

## 📱 Підтримка браузерів

- Chrome (остання версія)
- Firefox (остання версія)
- Safari (остання версія)
- Edge (остання версія)
- Mobile Safari (iOS 12+)
- Chrome Mobile (Android 8+)

## 🤝 Внесок у проєкт

Якщо ви хочете внести свій внесок:

1. Форкніть репозиторій
2. Створіть feature branch (`git checkout -b feature/AmazingFeature`)
3. Закомітьте зміни (`git commit -m 'Add some AmazingFeature'`)
4. Запуште branch (`git push origin feature/AmazingFeature`)
5. Відкрийте Pull Request

## 📝 Ліцензія

ISC License

## 👨‍💻 Автор

Alexander Repeta - [alexander.repeta@gmail.com](mailto:alexander.repeta@gmail.com)

---

**Зроблено з ❤️ в рамках курсу GoIT**

